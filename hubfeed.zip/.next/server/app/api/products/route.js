var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/products/route.js")
R.c("server/chunks/[root-of-the-server]__c8e9dd38._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_products_route_actions_9a81c53e.js")
R.m(86577)
module.exports=R.m(86577).exports
