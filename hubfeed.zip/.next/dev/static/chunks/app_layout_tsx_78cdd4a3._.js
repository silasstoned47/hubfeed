(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__36b083e1._.css",
  "static/chunks/node_modules_e9fc6eb5._.js",
  "static/chunks/_162a98a6._.js"
],
    source: "dynamic"
});
