module.exports = [
"[project]/.next-internal/server/app/create-ad/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_create-ad_page_actions_90a46491.js.map