module.exports = [
"[project]/.next-internal/server/app/terms/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_terms_page_actions_3b82705a.js.map