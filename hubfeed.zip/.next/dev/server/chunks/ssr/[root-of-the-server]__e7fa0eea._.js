module.exports = [
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/lib/utils.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-rsc] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
}),
"[project]/components/ui/Card.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Card",
    ()=>Card,
    "CardContent",
    ()=>CardContent,
    "CardDescription",
    ()=>CardDescription,
    "CardFooter",
    ()=>CardFooter,
    "CardHeader",
    ()=>CardHeader,
    "CardTitle",
    ()=>CardTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-rsc] (ecmascript)");
;
;
;
const Card = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("rounded-lg border border-slate-200 bg-white text-slate-950 shadow-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/Card.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("flex flex-col space-y-1.5 p-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/Card.tsx",
        lineNumber: 23,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("text-2xl font-semibold leading-none tracking-tight", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/Card.tsx",
        lineNumber: 35,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("text-sm text-slate-500", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/Card.tsx",
        lineNumber: 50,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/Card.tsx",
        lineNumber: 62,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("flex items-center p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/Card.tsx",
        lineNumber: 70,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
CardFooter.displayName = "CardFooter";
;
}),
"[project]/components/ui/Badge.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Badge",
    ()=>Badge,
    "badgeVariants",
    ()=>badgeVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-rsc] (ecmascript)");
;
;
;
const badgeVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-slate-950 focus:ring-offset-2", {
    variants: {
        variant: {
            default: "border-transparent bg-slate-900 text-slate-50 hover:bg-slate-900/80",
            secondary: "border-transparent bg-slate-100 text-slate-900 hover:bg-slate-100/80",
            destructive: "border-transparent bg-red-500 text-slate-50 hover:bg-red-500/80",
            outline: "text-slate-950"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
function Badge({ className, variant, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])(badgeVariants({
            variant
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/Badge.tsx",
        lineNumber: 31,
        columnNumber: 9
    }, this);
}
;
}),
"[project]/components/ui/Button.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-rsc] (ecmascript)");
;
;
;
;
// Note: I'm not using radix-ui/react-slot actually, just standard button for MVP simplicity unless I install radix.
// I'll stick to standard button for now to avoid extra deps not listed, but keep structure clean.
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50", {
    variants: {
        variant: {
            default: "bg-slate-900 text-slate-50 hover:bg-slate-900/90",
            destructive: "bg-red-500 text-slate-50 hover:bg-red-500/90",
            outline: "border border-slate-200 bg-white hover:bg-slate-100 hover:text-slate-900",
            secondary: "bg-slate-100 text-slate-900 hover:bg-slate-100/80",
            ghost: "hover:bg-slate-100 hover:text-slate-900",
            link: "text-slate-900 underline-offset-4 hover:underline"
        },
        size: {
            default: "h-10 px-4 py-2",
            sm: "h-9 rounded-md px-3",
            lg: "h-11 rounded-md px-8",
            icon: "h-10 w-10"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"](({ className, variant, size, asChild = false, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/Button.tsx",
        lineNumber: 44,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
Button.displayName = "Button";
;
}),
"[project]/components/features/ProductGrid.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductGrid",
    ()=>ProductGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/heart.js [app-rsc] (ecmascript) <export default as Heart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/Card.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Badge$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/Badge.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/Button.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$context$2f$StoreContext$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/context/StoreContext.tsx [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
function ProductGrid({ products }) {
    const { toggleFavorite, favorites } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$context$2f$StoreContext$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useStore"])();
    const isNew = (dateString)=>{
        const date = new Date(dateString);
        const now = new Date();
        const diffTime = Math.abs(now.getTime() - date.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays <= 7;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6",
        children: products.map((product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Card"], {
                className: "overflow-hidden group hover:shadow-md transition-shadow",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative aspect-square overflow-hidden bg-slate-100",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: product.images[0],
                                alt: product.title,
                                className: "object-cover w-full h-full transition-transform group-hover:scale-105"
                            }, void 0, false, {
                                fileName: "[project]/components/features/ProductGrid.tsx",
                                lineNumber: 38,
                                columnNumber: 25
                            }, this),
                            isNew(product.postedAt) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Badge$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Badge"], {
                                className: "absolute top-2 left-2 bg-green-500 hover:bg-green-600",
                                children: "Novo"
                            }, void 0, false, {
                                fileName: "[project]/components/features/ProductGrid.tsx",
                                lineNumber: 44,
                                columnNumber: 29
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "ghost",
                                size: "icon",
                                className: "absolute top-2 right-2 bg-white/80 hover:bg-white text-slate-900 rounded-full opacity-0 group-hover:opacity-100 transition-opacity",
                                onClick: (e)=>{
                                    e.preventDefault();
                                    toggleFavorite(product.id);
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"], {
                                    className: `h-5 w-5 ${favorites.includes(product.id) ? "fill-red-500 text-red-500" : ""}`
                                }, void 0, false, {
                                    fileName: "[project]/components/features/ProductGrid.tsx",
                                    lineNumber: 57,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/features/ProductGrid.tsx",
                                lineNumber: 48,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/features/ProductGrid.tsx",
                        lineNumber: 37,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["CardContent"], {
                        className: "p-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-start mb-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Badge$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Badge"], {
                                        variant: "secondary",
                                        className: "text-xs",
                                        children: product.category
                                    }, void 0, false, {
                                        fileName: "[project]/components/features/ProductGrid.tsx",
                                        lineNumber: 65,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-slate-500",
                                        children: product.condition
                                    }, void 0, false, {
                                        fileName: "[project]/components/features/ProductGrid.tsx",
                                        lineNumber: 68,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/features/ProductGrid.tsx",
                                lineNumber: 64,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                href: `/product/${product.id}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "font-semibold text-lg leading-tight mb-2 hover:text-indigo-600 truncate",
                                    children: product.title
                                }, void 0, false, {
                                    fileName: "[project]/components/features/ProductGrid.tsx",
                                    lineNumber: 71,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/features/ProductGrid.tsx",
                                lineNumber: 70,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "font-bold text-xl text-indigo-600",
                                children: new Intl.NumberFormat("pt-BR", {
                                    style: "currency",
                                    currency: "BRL"
                                }).format(product.price)
                            }, void 0, false, {
                                fileName: "[project]/components/features/ProductGrid.tsx",
                                lineNumber: 75,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/features/ProductGrid.tsx",
                        lineNumber: 63,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["CardFooter"], {
                        className: "p-4 pt-0",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                            href: `/product/${product.id}`,
                            className: "w-full",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "outline",
                                className: "w-full",
                                children: "Ver Detalhes"
                            }, void 0, false, {
                                fileName: "[project]/components/features/ProductGrid.tsx",
                                lineNumber: 84,
                                columnNumber: 29
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/features/ProductGrid.tsx",
                            lineNumber: 83,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/features/ProductGrid.tsx",
                        lineNumber: 82,
                        columnNumber: 21
                    }, this)
                ]
            }, product.id, true, {
                fileName: "[project]/components/features/ProductGrid.tsx",
                lineNumber: 36,
                columnNumber: 17
            }, this))
    }, void 0, false, {
        fileName: "[project]/components/features/ProductGrid.tsx",
        lineNumber: 34,
        columnNumber: 9
    }, this);
}
}),
"[project]/data/products.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v(JSON.parse("[{\"id\":\"1\",\"title\":\"Arranhador Castelo Real\",\"price\":250.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Arranhador de luxo com 3 andares, perfeito para gatos que amam altura.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"arranhador\",\"grande\",\"luxo\"],\"location\":\"São Paulo, SP\",\"sellerName\":\"Gatos & Cia\",\"postedAt\":\"2023-10-25T10:00:00Z\"},{\"id\":\"2\",\"title\":\"Ratinho de Sisal\",\"price\":15.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Brinquedo clássico, feito de sisal natural e resistente.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"sisal\",\"pequeno\",\"interativo\"],\"location\":\"Rio de Janeiro, RJ\",\"sellerName\":\"Ana Paula\",\"postedAt\":\"2023-10-26T14:30:00Z\"},{\"id\":\"3\",\"title\":\"Varinha com Penas Coloridas\",\"price\":25.9,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Estimule o instinto caçador do seu gato com esta varinha divertida.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"varinha\",\"penas\",\"interativo\"],\"location\":\"Curitiba, PR\",\"sellerName\":\"PetLove Store\",\"postedAt\":\"2023-10-20T09:15:00Z\"},{\"id\":\"4\",\"title\":\"Túnel Dobrável 3 Saídas\",\"price\":89.9,\"category\":\"Brinquedos\",\"condition\":\"Usado\",\"description\":\"Pouco uso, em ótimo estado. Seu gato vai adorar se esconder aqui.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"tunel\",\"esconderijo\"],\"location\":\"Belo Horizonte, MG\",\"sellerName\":\"Marcos Silva\",\"postedAt\":\"2023-10-27T11:00:00Z\"},{\"id\":\"5\",\"title\":\"Laser Pointer Automático\",\"price\":120.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Laser que se move sozinho, diversão garantida mesmo quando você não está.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"laser\",\"automatico\",\"eletronico\"],\"location\":\"Porto Alegre, RS\",\"sellerName\":\"TechPets\",\"postedAt\":\"2023-10-22T16:45:00Z\"},{\"id\":\"6\",\"title\":\"Bolinha com Guizo (Kit 3)\",\"price\":12.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Kit com 3 bolinhas coloridas que fazem barulho.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"bolinha\",\"guizo\",\"barato\"],\"location\":\"Salvador, BA\",\"sellerName\":\"Lojinha do Gato\",\"postedAt\":\"2023-10-28T08:20:00Z\"},{\"id\":\"7\",\"title\":\"Torre de Bolinhas 3 Níveis\",\"price\":45.0,\"category\":\"Brinquedos\",\"condition\":\"Usado\",\"description\":\"Brinquedo interativo, falta uma bolinha mas funciona perfeitamente.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"torre\",\"interativo\",\"plastico\"],\"location\":\"Recife, PE\",\"sellerName\":\"Julia M.\",\"postedAt\":\"2023-10-24T13:10:00Z\"},{\"id\":\"8\",\"title\":\"Peixe Eletrônico que se Mexe\",\"price\":65.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Carregamento USB, sensor de movimento. Parece um peixe de verdade!\",\"images\":[\"/products/toy.png\"],\"tags\":[\"peixe\",\"eletronico\",\"usb\"],\"location\":\"Fortaleza, CE\",\"sellerName\":\"Inova Pet\",\"postedAt\":\"2023-10-21T19:00:00Z\"},{\"id\":\"9\",\"title\":\"Arranhador de Papelão Ondulado\",\"price\":35.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Ecológico e irresistível para afiar as unhas.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"arranhador\",\"papelao\",\"ecologico\"],\"location\":\"Brasília, DF\",\"sellerName\":\"EcoGato\",\"postedAt\":\"2023-10-29T10:30:00Z\"},{\"id\":\"10\",\"title\":\"Catnip Orgânico Premium\",\"price\":20.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Erva do gato de alta potência, cultivada sem agrotóxicos.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"catnip\",\"erva\",\"organico\"],\"location\":\"Florianópolis, SC\",\"sellerName\":\"Green Paws\",\"postedAt\":\"2023-10-23T15:20:00Z\"},{\"id\":\"11\",\"title\":\"Labirinto para Petiscos\",\"price\":55.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Desafie a mente do seu gato enquanto ele tenta pegar a comida.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"puzzle\",\"comida\",\"inteligencia\"],\"location\":\"Manaus, AM\",\"sellerName\":\"Smart Cat\",\"postedAt\":\"2023-10-25T12:00:00Z\"},{\"id\":\"12\",\"title\":\"Ratinho de Pelúcia com Catnip\",\"price\":18.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Macio e recheado com a melhor erva do gato.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"pelucia\",\"catnip\",\"fofo\"],\"location\":\"Goiânia, GO\",\"sellerName\":\"Fofura Pets\",\"postedAt\":\"2023-10-26T09:45:00Z\"},{\"id\":\"13\",\"title\":\"Circuito de Bolinhas Iluminado\",\"price\":95.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Bolinhas que acendem com o movimento, ótimo para brincar à noite.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"circuito\",\"luz\",\"noturno\"],\"location\":\"Campinas, SP\",\"sellerName\":\"Night Cat\",\"postedAt\":\"2023-10-20T18:30:00Z\"},{\"id\":\"14\",\"title\":\"Cama Nuvem Super Macia\",\"price\":140.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"A cama mais confortável do mundo, alivia ansiedade.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"cama\",\"macia\",\"conforto\"],\"location\":\"São Paulo, SP\",\"sellerName\":\"Sono Pet\",\"postedAt\":\"2023-10-28T11:15:00Z\"},{\"id\":\"15\",\"title\":\"Toca Iglu Térmica\",\"price\":85.0,\"category\":\"Camas\",\"condition\":\"Usado\",\"description\":\"Mantém o calor, ideal para o inverno. Pouco uso.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"toca\",\"iglu\",\"quente\"],\"location\":\"Curitiba, PR\",\"sellerName\":\"Beatriz Costa\",\"postedAt\":\"2023-10-22T14:00:00Z\"},{\"id\":\"16\",\"title\":\"Rede de Janela com Ventosas\",\"price\":110.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Suporta até 15kg, seu gato vai amar ver a rua.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"rede\",\"janela\",\"vista\"],\"location\":\"Rio de Janeiro, RJ\",\"sellerName\":\"Vista Gato\",\"postedAt\":\"2023-10-29T09:30:00Z\"},{\"id\":\"17\",\"title\":\"Almofada Ortopédica\",\"price\":160.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Espuma viscoelástica, ideal para gatos idosos.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"ortopedica\",\"idoso\",\"saude\"],\"location\":\"Belo Horizonte, MG\",\"sellerName\":\"Vet Care\",\"postedAt\":\"2023-10-25T16:20:00Z\"},{\"id\":\"18\",\"title\":\"Cama Suspensa de Madeira\",\"price\":190.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Design moderno que combina com sua sala.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"madeira\",\"design\",\"moderno\"],\"location\":\"Porto Alegre, RS\",\"sellerName\":\"Wood Pets\",\"postedAt\":\"2023-10-21T10:45:00Z\"},{\"id\":\"19\",\"title\":\"Colchonete Refrescante\",\"price\":40.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Gel interno que refresca, perfeito para o verão.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"verao\",\"refrescante\",\"gel\"],\"location\":\"Salvador, BA\",\"sellerName\":\"Summer Cat\",\"postedAt\":\"2023-10-27T13:50:00Z\"},{\"id\":\"20\",\"title\":\"Cama Caverna de Feltro\",\"price\":95.0,\"category\":\"Camas\",\"condition\":\"Usado\",\"description\":\"Feita à mão, muito estilosa. Sem avarias.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"feltro\",\"artesanal\",\"caverna\"],\"location\":\"São Paulo, SP\",\"sellerName\":\"Carla Dias\",\"postedAt\":\"2023-10-23T17:10:00Z\"},{\"id\":\"21\",\"title\":\"Rede para Cadeira\",\"price\":35.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Aproveite o espaço embaixo da cadeira.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"rede\",\"cadeira\",\"espaco\"],\"location\":\"Recife, PE\",\"sellerName\":\"Space Save\",\"postedAt\":\"2023-10-26T11:25:00Z\"},{\"id\":\"22\",\"title\":\"Cama Banana Divertida\",\"price\":70.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Formato de banana, super fofa e quentinha.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"banana\",\"engracado\",\"amarelo\"],\"location\":\"Fortaleza, CE\",\"sellerName\":\"Fun Pets\",\"postedAt\":\"2023-10-24T15:30:00Z\"},{\"id\":\"23\",\"title\":\"Cesto de Vime com Almofada\",\"price\":130.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Rústico e elegante, inclui almofada lavável.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"vime\",\"rustico\",\"decoracao\"],\"location\":\"Florianópolis, SC\",\"sellerName\":\"Casa & Pet\",\"postedAt\":\"2023-10-20T12:40:00Z\"},{\"id\":\"24\",\"title\":\"Cama 2 em 1 (Toca e Cama)\",\"price\":80.0,\"category\":\"Camas\",\"condition\":\"Usado\",\"description\":\"Pode ser usada aberta ou fechada.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"versatil\",\"2em1\",\"pratico\"],\"location\":\"Brasília, DF\",\"sellerName\":\"Pedro H.\",\"postedAt\":\"2023-10-28T14:55:00Z\"},{\"id\":\"25\",\"title\":\"Tapete de Pelúcia\",\"price\":25.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Simples e macio, para colocar no sofá ou chão.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"tapete\",\"pelucia\",\"simples\"],\"location\":\"Manaus, AM\",\"sellerName\":\"Soft Touch\",\"postedAt\":\"2023-10-29T08:10:00Z\"},{\"id\":\"26\",\"title\":\"Cama Elevada Respirável\",\"price\":60.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Mantém o pet longe da umidade do chão.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"elevada\",\"higiene\",\"respiravel\"],\"location\":\"Goiânia, GO\",\"sellerName\":\"Clean Pet\",\"postedAt\":\"2023-10-22T10:50:00Z\"},{\"id\":\"27\",\"title\":\"Fantasia de Leão\",\"price\":45.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Transforme seu gatinho no rei da selva.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"fantasia\",\"leao\",\"engracado\"],\"location\":\"São Paulo, SP\",\"sellerName\":\"Party Pets\",\"postedAt\":\"2023-10-25T11:30:00Z\"},{\"id\":\"28\",\"title\":\"Suéter de Lã Tricotado\",\"price\":60.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Feito à mão, muito quentinho para dias frios.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"sueter\",\"inverno\",\"tricot\"],\"location\":\"Curitiba, PR\",\"sellerName\":\"Vovó Tricoteira\",\"postedAt\":\"2023-10-21T15:00:00Z\"},{\"id\":\"29\",\"title\":\"Colar Elizabetano Fofo (Pão)\",\"price\":35.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Alternativa confortável ao cone da vergonha.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"colar\",\"cirurgia\",\"pao\"],\"location\":\"Rio de Janeiro, RJ\",\"sellerName\":\"Care Pet\",\"postedAt\":\"2023-10-27T09:20:00Z\"},{\"id\":\"30\",\"title\":\"Camisa Havaiana\",\"price\":30.0,\"category\":\"Roupas\",\"condition\":\"Usado\",\"description\":\"Usada uma vez para fotos. Tamanho M.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"camisa\",\"verao\",\"estilo\"],\"location\":\"Salvador, BA\",\"sellerName\":\"Lucas M.\",\"postedAt\":\"2023-10-24T16:40:00Z\"},{\"id\":\"31\",\"title\":\"Capa de Chuva Amarela\",\"price\":50.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Impermeável e com capuz.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"chuva\",\"impermeavel\",\"capa\"],\"location\":\"Porto Alegre, RS\",\"sellerName\":\"Rainy Day\",\"postedAt\":\"2023-10-28T13:15:00Z\"},{\"id\":\"32\",\"title\":\"Gravata Borboleta Ajustável\",\"price\":15.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Para gatos elegantes. Várias cores.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"gravata\",\"acessorio\",\"elegante\"],\"location\":\"Belo Horizonte, MG\",\"sellerName\":\"GentleCat\",\"postedAt\":\"2023-10-23T11:55:00Z\"},{\"id\":\"33\",\"title\":\"Vestido Floral de Verão\",\"price\":40.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Tecido leve e fresco.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"vestido\",\"femea\",\"floral\"],\"location\":\"Recife, PE\",\"sellerName\":\"Moda Pet\",\"postedAt\":\"2023-10-26T14:10:00Z\"},{\"id\":\"34\",\"title\":\"Moletom com Capuz (Adidog)\",\"price\":55.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Estilo esportivo e urbano.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"moletom\",\"esporte\",\"frio\"],\"location\":\"São Paulo, SP\",\"sellerName\":\"Sport Pet\",\"postedAt\":\"2023-10-20T10:25:00Z\"},{\"id\":\"35\",\"title\":\"Fantasia de Morcego (Asas)\",\"price\":25.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Perfeito para o Halloween.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"halloween\",\"morcego\",\"fantasia\"],\"location\":\"Florianópolis, SC\",\"sellerName\":\"Spooky Cat\",\"postedAt\":\"2023-10-29T15:45:00Z\"},{\"id\":\"36\",\"title\":\"Bandana Personalizada\",\"price\":20.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Com o nome do seu gato bordado.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"bandana\",\"personalizado\",\"nome\"],\"location\":\"Brasília, DF\",\"sellerName\":\"Bordados da Ju\",\"postedAt\":\"2023-10-22T12:30:00Z\"},{\"id\":\"37\",\"title\":\"Pijama de Soft\",\"price\":45.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Para noites de sono tranquilas e quentinhas.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"pijama\",\"soft\",\"dormir\"],\"location\":\"Curitiba, PR\",\"sellerName\":\"Sleepy Cat\",\"postedAt\":\"2023-10-25T09:05:00Z\"},{\"id\":\"38\",\"title\":\"Chapéu de Aniversário\",\"price\":10.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Comemore o dia especial do seu gatinho.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"aniversario\",\"festa\",\"chapeu\"],\"location\":\"Rio de Janeiro, RJ\",\"sellerName\":\"Party Time\",\"postedAt\":\"2023-10-28T16:50:00Z\"},{\"id\":\"39\",\"title\":\"Fonte de Água Automática\",\"price\":180.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Água corrente estimula o gato a beber mais.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"fonte\",\"agua\",\"saude\"],\"location\":\"São Paulo, SP\",\"sellerName\":\"HidraPet\",\"postedAt\":\"2023-10-21T11:10:00Z\"},{\"id\":\"40\",\"title\":\"Caixa de Areia Fechada\",\"price\":120.0,\"category\":\"Acessórios\",\"condition\":\"Usado\",\"description\":\"Com filtro de carvão para odores. Bom estado.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"banheiro\",\"areia\",\"higiene\"],\"location\":\"Campinas, SP\",\"sellerName\":\"Roberto F.\",\"postedAt\":\"2023-10-27T10:40:00Z\"},{\"id\":\"41\",\"title\":\"Comedouro Elevado Ergonômico\",\"price\":50.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Evita refluxo e melhora a digestão.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"comedouro\",\"ergonomico\",\"saude\"],\"location\":\"Porto Alegre, RS\",\"sellerName\":\"ErgoPet\",\"postedAt\":\"2023-10-23T13:20:00Z\"},{\"id\":\"42\",\"title\":\"Escova Tira Pelos (Furminator)\",\"price\":90.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Remove até 90% dos pelos mortos.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"escova\",\"pelos\",\"higiene\"],\"location\":\"Belo Horizonte, MG\",\"sellerName\":\"Grooming Pro\",\"postedAt\":\"2023-10-29T14:15:00Z\"},{\"id\":\"43\",\"title\":\"Coleira com Identificação\",\"price\":25.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Segurança para seu gato, com placa gravada.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"coleira\",\"seguranca\",\"id\"],\"location\":\"Salvador, BA\",\"sellerName\":\"Safe Cat\",\"postedAt\":\"2023-10-20T15:55:00Z\"},{\"id\":\"44\",\"title\":\"Tapete Higiênico Coletor de Areia\",\"price\":45.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Evita que a areia se espalhe pela casa.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"tapete\",\"areia\",\"limpeza\"],\"location\":\"Recife, PE\",\"sellerName\":\"Casa Limpa\",\"postedAt\":\"2023-10-26T08:35:00Z\"},{\"id\":\"45\",\"title\":\"Caixa de Transporte Luxo\",\"price\":150.0,\"category\":\"Acessórios\",\"condition\":\"Usado\",\"description\":\"Aprovada para viagens de avião. Pouco uso.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"transporte\",\"viagem\",\"aviao\"],\"location\":\"Fortaleza, CE\",\"sellerName\":\"Viajante Pet\",\"postedAt\":\"2023-10-24T12:05:00Z\"},{\"id\":\"46\",\"title\":\"Cortador de Unhas com LED\",\"price\":35.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Luz LED ajuda a ver o vaso sanguíneo da unha.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"unhas\",\"corte\",\"led\"],\"location\":\"Manaus, AM\",\"sellerName\":\"Tech Care\",\"postedAt\":\"2023-10-28T17:30:00Z\"},{\"id\":\"47\",\"title\":\"Comedouro Automático Programável\",\"price\":250.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Programe os horários e quantidades de ração.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"automatico\",\"racao\",\"tecnologia\"],\"location\":\"Goiânia, GO\",\"sellerName\":\"Smart Feeder\",\"postedAt\":\"2023-10-22T09:50:00Z\"},{\"id\":\"48\",\"title\":\"Shampoo a Seco (Banho de Gato)\",\"price\":30.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Limpa sem precisar de água, ideal para gatos.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"banho\",\"shampoo\",\"higiene\"],\"location\":\"Brasília, DF\",\"sellerName\":\"Clean Cat\",\"postedAt\":\"2023-10-25T14:40:00Z\"},{\"id\":\"49\",\"title\":\"Peitoral e Guia para Passeio\",\"price\":40.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Seguro e confortável para passear com seu gato.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"passeio\",\"guia\",\"peitoral\"],\"location\":\"Florianópolis, SC\",\"sellerName\":\"Adventure Cat\",\"postedAt\":\"2023-10-21T13:15:00Z\"},{\"id\":\"50\",\"title\":\"Bebedouro de Cerâmica\",\"price\":75.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Mantém a água fresca, fácil de limpar.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"bebedouro\",\"ceramica\",\"fresco\"],\"location\":\"Rio de Janeiro, RJ\",\"sellerName\":\"Ceramica Pet\",\"postedAt\":\"2023-10-27T16:00:00Z\"}]"));}),
"[project]/app/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$features$2f$ProductGrid$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/features/ProductGrid.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/Button.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$products$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/data/products.json (json)");
;
;
;
;
;
async function getProducts(searchParams) {
    const { category, search, sort, page = "1" } = searchParams;
    const limit = 12;
    let filteredProducts = [
        ...__TURBOPACK__imported__module__$5b$project$5d2f$data$2f$products$2e$json__$28$json$29$__["default"]
    ];
    // Filter by Category
    if (category && category !== "Todos") {
        filteredProducts = filteredProducts.filter((p)=>p.category.toLowerCase() === category.toLowerCase());
    }
    // Filter by Search
    if (search) {
        const searchLower = search.toLowerCase();
        filteredProducts = filteredProducts.filter((p)=>p.title.toLowerCase().includes(searchLower) || p.tags.some((tag)=>tag.toLowerCase().includes(searchLower)));
    }
    // Sort
    if (sort === "price_asc") {
        filteredProducts.sort((a, b)=>a.price - b.price);
    } else if (sort === "price_desc") {
        filteredProducts.sort((a, b)=>b.price - a.price);
    } else if (sort === "date_desc") {
        filteredProducts.sort((a, b)=>new Date(b.postedAt).getTime() - new Date(a.postedAt).getTime());
    }
    // Pagination
    const startIndex = (parseInt(page) - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedProducts = filteredProducts.slice(startIndex, endIndex);
    return {
        data: paginatedProducts,
        meta: {
            total: filteredProducts.length,
            page: parseInt(page),
            limit,
            totalPages: Math.ceil(filteredProducts.length / limit)
        }
    };
}
async function Home({ searchParams }) {
    const { data: products, meta } = await getProducts(searchParams);
    const currentCategory = searchParams.category || "Todos";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col min-h-screen",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "bg-indigo-900 text-white py-20 px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-4xl md:text-6xl font-bold mb-6",
                            children: "Mime seu Gato com Estilo"
                        }, void 0, false, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 68,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xl md:text-2xl text-indigo-200 mb-8 max-w-2xl mx-auto",
                            children: "O marketplace exclusivo para itens customizados, brinquedos e acessórios para felinos."
                        }, void 0, false, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 71,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-center gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/create-ad",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Button"], {
                                        size: "lg",
                                        className: "bg-white text-indigo-900 hover:bg-indigo-50",
                                        children: "Vender Desapego"
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 76,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 75,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                    href: "#products",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Button"], {
                                        size: "lg",
                                        variant: "outline",
                                        className: "text-white border-white hover:bg-white/10",
                                        children: "Explorar Produtos"
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 81,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 80,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 74,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 67,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 66,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                id: "products",
                className: "container mx-auto px-4 py-12",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col md:flex-row gap-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                            className: "w-full md:w-64 space-y-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "font-semibold text-lg mb-4",
                                            children: "Categorias"
                                        }, void 0, false, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 95,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-col gap-2",
                                            children: [
                                                "Todos",
                                                "Brinquedos",
                                                "Camas",
                                                "Roupas",
                                                "Acessórios"
                                            ].map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                                    href: cat === "Todos" ? "/" : `/?category=${cat}`,
                                                    className: `px-4 py-2 rounded-md text-sm transition-colors ${currentCategory === cat ? "bg-indigo-100 text-indigo-700 font-medium" : "hover:bg-slate-100 text-slate-600"}`,
                                                    children: cat
                                                }, cat, false, {
                                                    fileName: "[project]/app/page.tsx",
                                                    lineNumber: 98,
                                                    columnNumber: 19
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 96,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 94,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "font-semibold text-lg mb-4",
                                            children: "Ordenar por"
                                        }, void 0, false, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 113,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-col gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                                    href: {
                                                        query: {
                                                            ...searchParams,
                                                            sort: "date_desc"
                                                        }
                                                    },
                                                    className: "text-sm text-slate-600 hover:text-indigo-600",
                                                    children: "Mais Recentes"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/page.tsx",
                                                    lineNumber: 115,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                                    href: {
                                                        query: {
                                                            ...searchParams,
                                                            sort: "price_asc"
                                                        }
                                                    },
                                                    className: "text-sm text-slate-600 hover:text-indigo-600",
                                                    children: "Menor Preço"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/page.tsx",
                                                    lineNumber: 116,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                                    href: {
                                                        query: {
                                                            ...searchParams,
                                                            sort: "price_desc"
                                                        }
                                                    },
                                                    className: "text-sm text-slate-600 hover:text-indigo-600",
                                                    children: "Maior Preço"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/page.tsx",
                                                    lineNumber: 117,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 114,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 112,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 93,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mb-6 flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "text-2xl font-bold text-slate-900",
                                            children: currentCategory === "Todos" ? "Destaques" : currentCategory
                                        }, void 0, false, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 125,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-sm text-slate-500",
                                            children: [
                                                meta.total,
                                                " produtos encontrados"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 128,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 124,
                                    columnNumber: 13
                                }, this),
                                products.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$features$2f$ProductGrid$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ProductGrid"], {
                                    products: products
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 134,
                                    columnNumber: 15
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center py-20 bg-slate-50 rounded-lg border border-dashed border-slate-300",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-slate-500",
                                        children: "Nenhum produto encontrado."
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 137,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 136,
                                    columnNumber: 15
                                }, this),
                                meta.totalPages > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-12 flex justify-center gap-2",
                                    children: Array.from({
                                        length: meta.totalPages
                                    }, (_, i)=>i + 1).map((page)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                            href: {
                                                query: {
                                                    ...searchParams,
                                                    page
                                                }
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: meta.page === page ? "default" : "outline",
                                                size: "sm",
                                                className: meta.page === page ? "bg-indigo-600" : "",
                                                children: page
                                            }, void 0, false, {
                                                fileName: "[project]/app/page.tsx",
                                                lineNumber: 149,
                                                columnNumber: 21
                                            }, this)
                                        }, page, false, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 145,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 143,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 123,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 91,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.tsx",
        lineNumber: 64,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__e7fa0eea._.js.map