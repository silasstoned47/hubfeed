globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/414e77373f8ff61c.js",
    "static/chunks/6a8b6d0f04868e51.js",
    "static/chunks/06525dfb60487280.js",
    "static/chunks/6740f161f60c6ab5.js",
    "static/chunks/turbopack-ae74ec8eec19a04a.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];