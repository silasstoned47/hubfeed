module.exports=[31696,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_product_%5Bid%5D_page_actions_aa98c3c9.js.map