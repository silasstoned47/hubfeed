module.exports = [
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/lib/utils.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-rsc] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
}),
"[project]/components/ui/Button.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-rsc] (ecmascript)");
;
;
;
;
// Note: I'm not using radix-ui/react-slot actually, just standard button for MVP simplicity unless I install radix.
// I'll stick to standard button for now to avoid extra deps not listed, but keep structure clean.
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50", {
    variants: {
        variant: {
            default: "bg-slate-900 text-slate-50 hover:bg-slate-900/90",
            destructive: "bg-red-500 text-slate-50 hover:bg-red-500/90",
            outline: "border border-slate-200 bg-white hover:bg-slate-100 hover:text-slate-900",
            secondary: "bg-slate-100 text-slate-900 hover:bg-slate-100/80",
            ghost: "hover:bg-slate-100 hover:text-slate-900",
            link: "text-slate-900 underline-offset-4 hover:underline"
        },
        size: {
            default: "h-10 px-4 py-2",
            sm: "h-9 rounded-md px-3",
            lg: "h-11 rounded-md px-8",
            icon: "h-10 w-10"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"](({ className, variant, size, asChild = false, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/Button.tsx",
        lineNumber: 44,
        columnNumber: 13
    }, ("TURBOPACK compile-time value", void 0));
});
Button.displayName = "Button";
;
}),
"[project]/components/ui/Badge.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Badge",
    ()=>Badge,
    "badgeVariants",
    ()=>badgeVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-rsc] (ecmascript)");
;
;
;
const badgeVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-slate-950 focus:ring-offset-2", {
    variants: {
        variant: {
            default: "border-transparent bg-slate-900 text-slate-50 hover:bg-slate-900/80",
            secondary: "border-transparent bg-slate-100 text-slate-900 hover:bg-slate-100/80",
            destructive: "border-transparent bg-red-500 text-slate-50 hover:bg-red-500/80",
            outline: "text-slate-950"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
function Badge({ className, variant, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])(badgeVariants({
            variant
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/Badge.tsx",
        lineNumber: 31,
        columnNumber: 9
    }, this);
}
;
}),
"[project]/components/features/ContactSellerModal.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "ContactSellerModal",
    ()=>ContactSellerModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const ContactSellerModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ContactSellerModal() from the server but ContactSellerModal is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/features/ContactSellerModal.tsx <module evaluation>", "ContactSellerModal");
}),
"[project]/components/features/ContactSellerModal.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "ContactSellerModal",
    ()=>ContactSellerModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const ContactSellerModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ContactSellerModal() from the server but ContactSellerModal is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/features/ContactSellerModal.tsx", "ContactSellerModal");
}),
"[project]/components/features/ContactSellerModal.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$features$2f$ContactSellerModal$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/features/ContactSellerModal.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$features$2f$ContactSellerModal$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/features/ContactSellerModal.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$features$2f$ContactSellerModal$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/data/products.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v(JSON.parse("[{\"id\":\"1\",\"title\":\"Arranhador Castelo Real\",\"price\":250.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Transforme a vida do seu gato com o Arranhador Castelo Real, a estrutura definitiva para diversão e descanso felino. Este arranhador de luxo não é apenas um acessório, é um verdadeiro palácio para o seu pet. Com três andares espaçosos, ele oferece múltiplas plataformas para o seu gato escalar, pular e observar o território, satisfazendo seus instintos naturais de caça e exploração. A estrutura é revestida com pelúcia de alta qualidade, proporcionando um toque suave e aconchegante para as sonecas da tarde. Os postes são envoltos em corda de sisal natural e resistente, perfeita para afiar as unhas. Isso é essencial para a saúde das garras do seu gato e, o melhor de tudo, ajuda a proteger seus móveis, sofás e cortinas de arranhões indesejados. O design do Castelo Real inclui uma toca privativa no andar térreo, ideal para momentos em que seu gato deseja se esconder ou dormir em total tranquilidade. No topo, uma plataforma de observação com bordas elevadas oferece a segurança que eles amam. Além disso, brinquedos pendurados em cordas elásticas estão estrategicamente posicionados para estimular brincadeiras ativas, ajudando a combater o tédio e o estresse. Este arranhador é robusto e estável, garantindo segurança mesmo para gatos maiores ou mais agitados. A montagem é simples e intuitiva, e seu design elegante em tons neutros combina perfeitamente com qualquer decoração. Invista no bem-estar do seu companheiro de quatro patas. O Arranhador Castelo Real é mais do que um brinquedo; é um investimento na saúde física e mental do seu gato, proporcionando exercício, diversão e relaxamento em um só lugar. Não perca a oportunidade de dar ao seu gato o reinado que ele merece!\",\"images\":[\"/products/scratcher.png\"],\"tags\":[\"arranhador\",\"grande\",\"luxo\"],\"location\":\"São Paulo, SP\",\"sellerName\":\"Gatos & Cia\",\"postedAt\":\"2023-10-25T10:00:00Z\"},{\"id\":\"2\",\"title\":\"Ratinho de Sisal\",\"price\":15.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"O Ratinho de Sisal é o brinquedo clássico que nunca sai de moda e que todo gato precisa ter em sua coleção. Simples, mas incrivelmente eficaz, este pequeno brinquedo foi desenhado para despertar o predador interior que existe em cada felino doméstico. Feito com um corpo estruturado revestido em sisal natural trançado, ele oferece uma textura irresistível que os gatos adoram morder e agarrar com as unhas, proporcionando uma satisfação tátil única que brinquedos de plástico ou borracha simplesmente não conseguem igualar. A durabilidade é um dos pontos fortes deste produto. O sisal é conhecido por sua resistência, suportando as brincadeiras mais intensas, mordidas e patadas sem se desfazer facilmente. Isso significa que o Ratinho de Sisal será um companheiro de longa data para o seu pet. Além da textura, o formato anatômico imita perfeitamente uma presa pequena, ativando instantaneamente o instinto de caça. Seu gato vai adorar persegui-lo pela casa, jogá-lo para o alto e carregá-lo na boca como um troféu, o que proporciona um excelente exercício físico, ajudando a manter o peso ideal e a agilidade. Para tornar a brincadeira ainda mais estimulante, o ratinho possui uma cauda de penas ou corda (dependendo do modelo) que adiciona movimento imprevisível quando arremessado, simulando a fuga de uma presa real. É o brinquedo perfeito para brincadeiras interativas entre você e seu gato: você joga, ele busca. Esse tipo de interação fortalece o vínculo entre tutor e pet, criando memórias divertidas e momentos de carinho. Ideal para gatos de todas as idades, desde filhotes cheios de energia até gatos idosos que precisam de um estímulo suave para se movimentar. O tamanho compacto permite que ele seja levado para qualquer lugar, garantindo a diversão em viagens ou visitas. Além disso, o sisal ajuda na limpeza mecânica dos dentes durante as mordidas, contribuindo para a saúde bucal. Seguro, natural e divertido, o Ratinho de Sisal é a escolha certa para quem busca um brinquedo acessível, mas de alto valor de entretenimento para seu companheiro felino.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"sisal\",\"pequeno\",\"interativo\"],\"location\":\"Rio de Janeiro, RJ\",\"sellerName\":\"Ana Paula\",\"postedAt\":\"2023-10-26T14:30:00Z\"},{\"id\":\"3\",\"title\":\"Varinha com Penas Coloridas\",\"price\":25.9,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"A Varinha com Penas Coloridas é a ferramenta definitiva para interação e exercício, projetada para criar momentos mágicos de conexão entre você e seu gato. Se você procura uma maneira de tirar seu gato do sofá e fazê-lo correr, pular e dar piruetas no ar, este é o brinquedo ideal. A varinha funciona como uma extensão do seu braço, permitindo que você controle o movimento das penas de forma a imitar o voo de um pássaro ou o rastejar de um inseto, movimentos que são gatilhos irresistíveis para o instinto de caça dos felinos. Na ponta de uma haste flexível e resistente, encontra-se um conjunto exuberante de penas naturais tingidas com corantes atóxicos e seguros. As cores vibrantes e a textura suave das penas capturam a atenção visual e tátil do gato instantaneamente. Quando agitada, a varinha produz um som sutil de 'swoosh' que aguça a audição sensível dos gatos, deixando-os em estado de alerta máximo e prontos para o ataque. É fascinante observar a concentração e a agilidade do seu pet enquanto ele tenta capturar a 'presa' voadora. Este brinquedo é fundamental para combater o sedentarismo, especialmente em gatos que vivem em apartamentos e têm espaço limitado para correr. Sessões diárias de 10 a 15 minutos com a Varinha com Penas Coloridas podem queimar calorias significativas, prevenindo a obesidade e problemas articulares, além de liberar endorfinas que deixam o gato mais relaxado e feliz após a brincadeira. É também uma excelente ferramenta para redirecionar comportamentos agressivos ou destrutivos, canalizando a energia acumulada para uma atividade saudável. A haste é longa o suficiente para manter suas mãos a uma distância segura das unhas e dentes afiados durante a empolgação da caça. Leve e fácil de manusear, permite que crianças e idosos também brinquem com o pet sem esforço. Lembre-se de guardar a varinha em um local seguro após o uso, para que o gato não destrua as penas sozinho e para manter o fator novidade sempre que você a pegar. Com a Varinha com Penas Coloridas, a diversão é garantida e a saúde do seu gato agradece.\",\"images\":[\"/products/wand.png\"],\"tags\":[\"varinha\",\"penas\",\"interativo\"],\"location\":\"Curitiba, PR\",\"sellerName\":\"PetLove Store\",\"postedAt\":\"2023-10-20T09:15:00Z\"},{\"id\":\"4\",\"title\":\"Túnel Dobrável 3 Saídas\",\"price\":89.9,\"category\":\"Brinquedos\",\"condition\":\"Usado\",\"description\":\"Pouco uso, em ótimo estado. Seu gato vai adorar se esconder aqui.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"tunel\",\"esconderijo\"],\"location\":\"Belo Horizonte, MG\",\"sellerName\":\"Marcos Silva\",\"postedAt\":\"2023-10-27T11:00:00Z\"},{\"id\":\"5\",\"title\":\"Laser Pointer Automático\",\"price\":120.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Laser que se move sozinho, diversão garantida mesmo quando você não está.\",\"images\":[\"/products/laser.png\"],\"tags\":[\"laser\",\"automatico\",\"eletronico\"],\"location\":\"Porto Alegre, RS\",\"sellerName\":\"TechPets\",\"postedAt\":\"2023-10-22T16:45:00Z\"},{\"id\":\"6\",\"title\":\"Bolinha com Guizo (Kit 3)\",\"price\":12.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Kit com 3 bolinhas coloridas que fazem barulho.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"bolinha\",\"guizo\",\"barato\"],\"location\":\"Salvador, BA\",\"sellerName\":\"Lojinha do Gato\",\"postedAt\":\"2023-10-28T08:20:00Z\"},{\"id\":\"7\",\"title\":\"Torre de Bolinhas 3 Níveis\",\"price\":45.0,\"category\":\"Brinquedos\",\"condition\":\"Usado\",\"description\":\"Brinquedo interativo, falta uma bolinha mas funciona perfeitamente.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"torre\",\"interativo\",\"plastico\"],\"location\":\"Recife, PE\",\"sellerName\":\"Julia M.\",\"postedAt\":\"2023-10-24T13:10:00Z\"},{\"id\":\"8\",\"title\":\"Peixe Eletrônico que se Mexe\",\"price\":65.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Carregamento USB, sensor de movimento. Parece um peixe de verdade!\",\"images\":[\"/products/toy.png\"],\"tags\":[\"peixe\",\"eletronico\",\"usb\"],\"location\":\"Fortaleza, CE\",\"sellerName\":\"Inova Pet\",\"postedAt\":\"2023-10-21T19:00:00Z\"},{\"id\":\"9\",\"title\":\"Arranhador de Papelão Ondulado\",\"price\":35.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Ecológico e irresistível para afiar as unhas.\",\"images\":[\"/products/scratcher.png\"],\"tags\":[\"arranhador\",\"papelao\",\"ecologico\"],\"location\":\"Brasília, DF\",\"sellerName\":\"EcoGato\",\"postedAt\":\"2023-10-29T10:30:00Z\"},{\"id\":\"10\",\"title\":\"Catnip Orgânico Premium\",\"price\":20.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Erva do gato de alta potência, cultivada sem agrotóxicos.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"catnip\",\"erva\",\"organico\"],\"location\":\"Florianópolis, SC\",\"sellerName\":\"Green Paws\",\"postedAt\":\"2023-10-23T15:20:00Z\"},{\"id\":\"11\",\"title\":\"Labirinto para Petiscos\",\"price\":55.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Desafie a mente do seu gato enquanto ele tenta pegar a comida.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"puzzle\",\"comida\",\"inteligencia\"],\"location\":\"Manaus, AM\",\"sellerName\":\"Smart Cat\",\"postedAt\":\"2023-10-25T12:00:00Z\"},{\"id\":\"12\",\"title\":\"Ratinho de Pelúcia com Catnip\",\"price\":18.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Macio e recheado com a melhor erva do gato.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"pelucia\",\"catnip\",\"fofo\"],\"location\":\"Goiânia, GO\",\"sellerName\":\"Fofura Pets\",\"postedAt\":\"2023-10-26T09:45:00Z\"},{\"id\":\"13\",\"title\":\"Circuito de Bolinhas Iluminado\",\"price\":95.0,\"category\":\"Brinquedos\",\"condition\":\"Novo\",\"description\":\"Bolinhas que acendem com o movimento, ótimo para brincar à noite.\",\"images\":[\"/products/toy.png\"],\"tags\":[\"circuito\",\"luz\",\"noturno\"],\"location\":\"Campinas, SP\",\"sellerName\":\"Night Cat\",\"postedAt\":\"2023-10-20T18:30:00Z\"},{\"id\":\"14\",\"title\":\"Cama Nuvem Super Macia\",\"price\":140.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"A cama mais confortável do mundo, alivia ansiedade.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"cama\",\"macia\",\"conforto\"],\"location\":\"São Paulo, SP\",\"sellerName\":\"Sono Pet\",\"postedAt\":\"2023-10-28T11:15:00Z\"},{\"id\":\"15\",\"title\":\"Toca Iglu Térmica\",\"price\":85.0,\"category\":\"Camas\",\"condition\":\"Usado\",\"description\":\"Mantém o calor, ideal para o inverno. Pouco uso.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"toca\",\"iglu\",\"quente\"],\"location\":\"Curitiba, PR\",\"sellerName\":\"Beatriz Costa\",\"postedAt\":\"2023-10-22T14:00:00Z\"},{\"id\":\"16\",\"title\":\"Rede de Janela com Ventosas\",\"price\":110.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Suporta até 15kg, seu gato vai amar ver a rua.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"rede\",\"janela\",\"vista\"],\"location\":\"Rio de Janeiro, RJ\",\"sellerName\":\"Vista Gato\",\"postedAt\":\"2023-10-29T09:30:00Z\"},{\"id\":\"17\",\"title\":\"Almofada Ortopédica\",\"price\":160.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Espuma viscoelástica, ideal para gatos idosos.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"ortopedica\",\"idoso\",\"saude\"],\"location\":\"Belo Horizonte, MG\",\"sellerName\":\"Vet Care\",\"postedAt\":\"2023-10-25T16:20:00Z\"},{\"id\":\"18\",\"title\":\"Cama Suspensa de Madeira\",\"price\":190.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Design moderno que combina com sua sala.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"madeira\",\"design\",\"moderno\"],\"location\":\"Porto Alegre, RS\",\"sellerName\":\"Wood Pets\",\"postedAt\":\"2023-10-21T10:45:00Z\"},{\"id\":\"19\",\"title\":\"Colchonete Refrescante\",\"price\":40.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Gel interno que refresca, perfeito para o verão.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"verao\",\"refrescante\",\"gel\"],\"location\":\"Salvador, BA\",\"sellerName\":\"Summer Cat\",\"postedAt\":\"2023-10-27T13:50:00Z\"},{\"id\":\"20\",\"title\":\"Cama Caverna de Feltro\",\"price\":95.0,\"category\":\"Camas\",\"condition\":\"Usado\",\"description\":\"Feita à mão, muito estilosa. Sem avarias.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"feltro\",\"artesanal\",\"caverna\"],\"location\":\"São Paulo, SP\",\"sellerName\":\"Carla Dias\",\"postedAt\":\"2023-10-23T17:10:00Z\"},{\"id\":\"21\",\"title\":\"Rede para Cadeira\",\"price\":35.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Aproveite o espaço embaixo da cadeira.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"rede\",\"cadeira\",\"espaco\"],\"location\":\"Recife, PE\",\"sellerName\":\"Space Save\",\"postedAt\":\"2023-10-26T11:25:00Z\"},{\"id\":\"22\",\"title\":\"Cama Banana Divertida\",\"price\":70.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Formato de banana, super fofa e quentinha.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"banana\",\"engracado\",\"amarelo\"],\"location\":\"Fortaleza, CE\",\"sellerName\":\"Fun Pets\",\"postedAt\":\"2023-10-24T15:30:00Z\"},{\"id\":\"23\",\"title\":\"Cesto de Vime com Almofada\",\"price\":130.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Rústico e elegante, inclui almofada lavável.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"vime\",\"rustico\",\"decoracao\"],\"location\":\"Florianópolis, SC\",\"sellerName\":\"Casa & Pet\",\"postedAt\":\"2023-10-20T12:40:00Z\"},{\"id\":\"24\",\"title\":\"Cama 2 em 1 (Toca e Cama)\",\"price\":80.0,\"category\":\"Camas\",\"condition\":\"Usado\",\"description\":\"Pode ser usada aberta ou fechada.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"versatil\",\"2em1\",\"pratico\"],\"location\":\"Brasília, DF\",\"sellerName\":\"Pedro H.\",\"postedAt\":\"2023-10-28T14:55:00Z\"},{\"id\":\"25\",\"title\":\"Tapete de Pelúcia\",\"price\":25.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Simples e macio, para colocar no sofá ou chão.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"tapete\",\"pelucia\",\"simples\"],\"location\":\"Manaus, AM\",\"sellerName\":\"Soft Touch\",\"postedAt\":\"2023-10-29T08:10:00Z\"},{\"id\":\"26\",\"title\":\"Cama Elevada Respirável\",\"price\":60.0,\"category\":\"Camas\",\"condition\":\"Novo\",\"description\":\"Mantém o pet longe da umidade do chão.\",\"images\":[\"/products/bed.png\"],\"tags\":[\"elevada\",\"higiene\",\"respiravel\"],\"location\":\"Goiânia, GO\",\"sellerName\":\"Clean Pet\",\"postedAt\":\"2023-10-22T10:50:00Z\"},{\"id\":\"27\",\"title\":\"Fantasia de Leão\",\"price\":45.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Transforme seu gatinho no rei da selva.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"fantasia\",\"leao\",\"engracado\"],\"location\":\"São Paulo, SP\",\"sellerName\":\"Party Pets\",\"postedAt\":\"2023-10-25T11:30:00Z\"},{\"id\":\"28\",\"title\":\"Suéter de Lã Tricotado\",\"price\":60.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Feito à mão, muito quentinho para dias frios.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"sueter\",\"inverno\",\"tricot\"],\"location\":\"Curitiba, PR\",\"sellerName\":\"Vovó Tricoteira\",\"postedAt\":\"2023-10-21T15:00:00Z\"},{\"id\":\"29\",\"title\":\"Colar Elizabetano Fofo (Pão)\",\"price\":35.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Alternativa confortável ao cone da vergonha.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"colar\",\"cirurgia\",\"pao\"],\"location\":\"Rio de Janeiro, RJ\",\"sellerName\":\"Care Pet\",\"postedAt\":\"2023-10-27T09:20:00Z\"},{\"id\":\"30\",\"title\":\"Camisa Havaiana\",\"price\":30.0,\"category\":\"Roupas\",\"condition\":\"Usado\",\"description\":\"Usada uma vez para fotos. Tamanho M.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"camisa\",\"verao\",\"estilo\"],\"location\":\"Salvador, BA\",\"sellerName\":\"Lucas M.\",\"postedAt\":\"2023-10-24T16:40:00Z\"},{\"id\":\"31\",\"title\":\"Capa de Chuva Amarela\",\"price\":50.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Impermeável e com capuz.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"chuva\",\"impermeavel\",\"capa\"],\"location\":\"Porto Alegre, RS\",\"sellerName\":\"Rainy Day\",\"postedAt\":\"2023-10-28T13:15:00Z\"},{\"id\":\"32\",\"title\":\"Gravata Borboleta Ajustável\",\"price\":15.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Para gatos elegantes. Várias cores.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"gravata\",\"acessorio\",\"elegante\"],\"location\":\"Belo Horizonte, MG\",\"sellerName\":\"GentleCat\",\"postedAt\":\"2023-10-23T11:55:00Z\"},{\"id\":\"33\",\"title\":\"Vestido Floral de Verão\",\"price\":40.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Tecido leve e fresco.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"vestido\",\"femea\",\"floral\"],\"location\":\"Recife, PE\",\"sellerName\":\"Moda Pet\",\"postedAt\":\"2023-10-26T14:10:00Z\"},{\"id\":\"34\",\"title\":\"Moletom com Capuz (Adidog)\",\"price\":55.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Estilo esportivo e urbano.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"moletom\",\"esporte\",\"frio\"],\"location\":\"São Paulo, SP\",\"sellerName\":\"Sport Pet\",\"postedAt\":\"2023-10-20T10:25:00Z\"},{\"id\":\"35\",\"title\":\"Fantasia de Morcego (Asas)\",\"price\":25.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Perfeito para o Halloween.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"halloween\",\"morcego\",\"fantasia\"],\"location\":\"Florianópolis, SC\",\"sellerName\":\"Spooky Cat\",\"postedAt\":\"2023-10-29T15:45:00Z\"},{\"id\":\"36\",\"title\":\"Bandana Personalizada\",\"price\":20.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Com o nome do seu gato bordado.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"bandana\",\"personalizado\",\"nome\"],\"location\":\"Brasília, DF\",\"sellerName\":\"Bordados da Ju\",\"postedAt\":\"2023-10-22T12:30:00Z\"},{\"id\":\"37\",\"title\":\"Pijama de Soft\",\"price\":45.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Para noites de sono tranquilas e quentinhas.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"pijama\",\"soft\",\"dormir\"],\"location\":\"Curitiba, PR\",\"sellerName\":\"Sleepy Cat\",\"postedAt\":\"2023-10-25T09:05:00Z\"},{\"id\":\"38\",\"title\":\"Chapéu de Aniversário\",\"price\":10.0,\"category\":\"Roupas\",\"condition\":\"Novo\",\"description\":\"Comemore o dia especial do seu gatinho.\",\"images\":[\"/products/clothes.png\"],\"tags\":[\"aniversario\",\"festa\",\"chapeu\"],\"location\":\"Rio de Janeiro, RJ\",\"sellerName\":\"Party Time\",\"postedAt\":\"2023-10-28T16:50:00Z\"},{\"id\":\"39\",\"title\":\"Fonte de Água Automática\",\"price\":180.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Água corrente estimula o gato a beber mais.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"fonte\",\"agua\",\"saude\"],\"location\":\"São Paulo, SP\",\"sellerName\":\"HidraPet\",\"postedAt\":\"2023-10-21T11:10:00Z\"},{\"id\":\"40\",\"title\":\"Caixa de Areia Fechada\",\"price\":120.0,\"category\":\"Acessórios\",\"condition\":\"Usado\",\"description\":\"Com filtro de carvão para odores. Bom estado.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"banheiro\",\"areia\",\"higiene\"],\"location\":\"Campinas, SP\",\"sellerName\":\"Roberto F.\",\"postedAt\":\"2023-10-27T10:40:00Z\"},{\"id\":\"41\",\"title\":\"Comedouro Elevado Ergonômico\",\"price\":50.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Evita refluxo e melhora a digestão.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"comedouro\",\"ergonomico\",\"saude\"],\"location\":\"Porto Alegre, RS\",\"sellerName\":\"ErgoPet\",\"postedAt\":\"2023-10-23T13:20:00Z\"},{\"id\":\"42\",\"title\":\"Escova Tira Pelos (Furminator)\",\"price\":90.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Remove até 90% dos pelos mortos.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"escova\",\"pelos\",\"higiene\"],\"location\":\"Belo Horizonte, MG\",\"sellerName\":\"Grooming Pro\",\"postedAt\":\"2023-10-29T14:15:00Z\"},{\"id\":\"43\",\"title\":\"Coleira com Identificação\",\"price\":25.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Segurança para seu gato, com placa gravada.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"coleira\",\"seguranca\",\"id\"],\"location\":\"Salvador, BA\",\"sellerName\":\"Safe Cat\",\"postedAt\":\"2023-10-20T15:55:00Z\"},{\"id\":\"44\",\"title\":\"Tapete Higiênico Coletor de Areia\",\"price\":45.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Evita que a areia se espalhe pela casa.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"tapete\",\"areia\",\"limpeza\"],\"location\":\"Recife, PE\",\"sellerName\":\"Casa Limpa\",\"postedAt\":\"2023-10-26T08:35:00Z\"},{\"id\":\"45\",\"title\":\"Caixa de Transporte Luxo\",\"price\":150.0,\"category\":\"Acessórios\",\"condition\":\"Usado\",\"description\":\"Aprovada para viagens de avião. Pouco uso.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"transporte\",\"viagem\",\"aviao\"],\"location\":\"Fortaleza, CE\",\"sellerName\":\"Viajante Pet\",\"postedAt\":\"2023-10-24T12:05:00Z\"},{\"id\":\"46\",\"title\":\"Cortador de Unhas com LED\",\"price\":35.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Luz LED ajuda a ver o vaso sanguíneo da unha.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"unhas\",\"corte\",\"led\"],\"location\":\"Manaus, AM\",\"sellerName\":\"Tech Care\",\"postedAt\":\"2023-10-28T17:30:00Z\"},{\"id\":\"47\",\"title\":\"Comedouro Automático Programável\",\"price\":250.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Programe os horários e quantidades de ração.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"automatico\",\"racao\",\"tecnologia\"],\"location\":\"Goiânia, GO\",\"sellerName\":\"Smart Feeder\",\"postedAt\":\"2023-10-22T09:50:00Z\"},{\"id\":\"48\",\"title\":\"Shampoo a Seco (Banho de Gato)\",\"price\":30.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Limpa sem precisar de água, ideal para gatos.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"banho\",\"shampoo\",\"higiene\"],\"location\":\"Brasília, DF\",\"sellerName\":\"Clean Cat\",\"postedAt\":\"2023-10-25T14:40:00Z\"},{\"id\":\"49\",\"title\":\"Peitoral e Guia para Passeio\",\"price\":40.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Seguro e confortável para passear com seu gato.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"passeio\",\"guia\",\"peitoral\"],\"location\":\"Florianópolis, SC\",\"sellerName\":\"Adventure Cat\",\"postedAt\":\"2023-10-21T13:15:00Z\"},{\"id\":\"50\",\"title\":\"Bebedouro de Cerâmica\",\"price\":75.0,\"category\":\"Acessórios\",\"condition\":\"Novo\",\"description\":\"Mantém a água fresca, fácil de limpar.\",\"images\":[\"/products/accessories.png\"],\"tags\":[\"bebedouro\",\"ceramica\",\"fresco\"],\"location\":\"Rio de Janeiro, RJ\",\"sellerName\":\"Ceramica Pet\",\"postedAt\":\"2023-10-27T16:00:00Z\"}]"));}),
"[project]/app/product/[id]/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProductPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/arrow-left.js [app-rsc] (ecmascript) <export default as ArrowLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-rsc] (ecmascript) <export default as MapPin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/calendar.js [app-rsc] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/tag.js [app-rsc] (ecmascript) <export default as Tag>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$share$2d$2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Share2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/share-2.js [app-rsc] (ecmascript) <export default as Share2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/Button.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Badge$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/Badge.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$features$2f$ContactSellerModal$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/features/ContactSellerModal.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$products$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/data/products.json (json)");
;
;
;
;
;
;
;
;
async function getProduct(id) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$products$2e$json__$28$json$29$__["default"].find((p)=>p.id === id) || null;
}
async function ProductPage({ params }) {
    const resolvedParams = await params;
    const product = await getProduct(resolvedParams.id);
    if (!product) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mx-auto px-4 py-8",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                href: "/",
                className: "inline-flex items-center text-sm text-slate-500 hover:text-indigo-600 mb-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__["ArrowLeft"], {
                        className: "h-4 w-4 mr-1"
                    }, void 0, false, {
                        fileName: "[project]/app/product/[id]/page.tsx",
                        lineNumber: 27,
                        columnNumber: 17
                    }, this),
                    "Voltar para a loja"
                ]
            }, void 0, true, {
                fileName: "[project]/app/product/[id]/page.tsx",
                lineNumber: 23,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 md:grid-cols-2 gap-12",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "aspect-square bg-slate-100 rounded-xl overflow-hidden border border-slate-200",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: product.images[0],
                                    alt: product.title,
                                    className: "w-full h-full object-cover"
                                }, void 0, false, {
                                    fileName: "[project]/app/product/[id]/page.tsx",
                                    lineNumber: 35,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/product/[id]/page.tsx",
                                lineNumber: 34,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-4 gap-4",
                                children: product.images.map((img, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "aspect-square bg-slate-100 rounded-lg overflow-hidden border border-slate-200 cursor-pointer hover:ring-2 ring-indigo-500",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: img,
                                            alt: `${product.title} ${i + 1}`,
                                            className: "w-full h-full object-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/app/product/[id]/page.tsx",
                                            lineNumber: 47,
                                            columnNumber: 33
                                        }, this)
                                    }, i, false, {
                                        fileName: "[project]/app/product/[id]/page.tsx",
                                        lineNumber: 43,
                                        columnNumber: 29
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/product/[id]/page.tsx",
                                lineNumber: 41,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/product/[id]/page.tsx",
                        lineNumber: 33,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Badge$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Badge"], {
                                        variant: "secondary",
                                        children: product.category
                                    }, void 0, false, {
                                        fileName: "[project]/app/product/[id]/page.tsx",
                                        lineNumber: 60,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Badge$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Badge"], {
                                        variant: product.condition === "Novo" ? "default" : "outline",
                                        children: product.condition
                                    }, void 0, false, {
                                        fileName: "[project]/app/product/[id]/page.tsx",
                                        lineNumber: 61,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/product/[id]/page.tsx",
                                lineNumber: 59,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-3xl font-bold text-slate-900 mb-2",
                                children: product.title
                            }, void 0, false, {
                                fileName: "[project]/app/product/[id]/page.tsx",
                                lineNumber: 66,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-4 text-sm text-slate-500 mb-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                                className: "h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "[project]/app/product/[id]/page.tsx",
                                                lineNumber: 72,
                                                columnNumber: 29
                                            }, this),
                                            " ",
                                            product.location
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/product/[id]/page.tsx",
                                        lineNumber: 71,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                                className: "h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "[project]/app/product/[id]/page.tsx",
                                                lineNumber: 75,
                                                columnNumber: 29
                                            }, this),
                                            " Postado em",
                                            " ",
                                            new Date(product.postedAt).toLocaleDateString("pt-BR")
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/product/[id]/page.tsx",
                                        lineNumber: 74,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/product/[id]/page.tsx",
                                lineNumber: 70,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-4xl font-bold text-indigo-600 mb-8",
                                children: new Intl.NumberFormat("pt-BR", {
                                    style: "currency",
                                    currency: "BRL"
                                }).format(product.price)
                            }, void 0, false, {
                                fileName: "[project]/app/product/[id]/page.tsx",
                                lineNumber: 80,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "prose prose-slate mb-8",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-lg font-semibold mb-2",
                                        children: "Descrição"
                                    }, void 0, false, {
                                        fileName: "[project]/app/product/[id]/page.tsx",
                                        lineNumber: 88,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-slate-600 leading-relaxed",
                                        children: product.description
                                    }, void 0, false, {
                                        fileName: "[project]/app/product/[id]/page.tsx",
                                        lineNumber: 89,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/product/[id]/page.tsx",
                                lineNumber: 87,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap gap-2 mb-8",
                                children: product.tags.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-800",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__["Tag"], {
                                                className: "h-3 w-3 mr-1"
                                            }, void 0, false, {
                                                fileName: "[project]/app/product/[id]/page.tsx",
                                                lineNumber: 100,
                                                columnNumber: 33
                                            }, this),
                                            tag
                                        ]
                                    }, tag, true, {
                                        fileName: "[project]/app/product/[id]/page.tsx",
                                        lineNumber: 96,
                                        columnNumber: 29
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/product/[id]/page.tsx",
                                lineNumber: 94,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col sm:flex-row gap-4 p-6 bg-slate-50 rounded-xl border border-slate-200",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm text-slate-500 mb-1",
                                                children: "Vendido por"
                                            }, void 0, false, {
                                                fileName: "[project]/app/product/[id]/page.tsx",
                                                lineNumber: 108,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "font-semibold text-slate-900",
                                                children: product.sellerName
                                            }, void 0, false, {
                                                fileName: "[project]/app/product/[id]/page.tsx",
                                                lineNumber: 109,
                                                columnNumber: 29
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/product/[id]/page.tsx",
                                        lineNumber: 107,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "outline",
                                                size: "icon",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$share$2d$2$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Share2$3e$__["Share2"], {
                                                    className: "h-5 w-5"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/product/[id]/page.tsx",
                                                    lineNumber: 113,
                                                    columnNumber: 33
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/product/[id]/page.tsx",
                                                lineNumber: 112,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$features$2f$ContactSellerModal$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ContactSellerModal"], {
                                                productTitle: product.title
                                            }, void 0, false, {
                                                fileName: "[project]/app/product/[id]/page.tsx",
                                                lineNumber: 115,
                                                columnNumber: 29
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/product/[id]/page.tsx",
                                        lineNumber: 111,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/product/[id]/page.tsx",
                                lineNumber: 106,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/product/[id]/page.tsx",
                        lineNumber: 58,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/product/[id]/page.tsx",
                lineNumber: 31,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/product/[id]/page.tsx",
        lineNumber: 22,
        columnNumber: 9
    }, this);
}
}),
"[project]/app/product/[id]/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/product/[id]/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__390f1977._.js.map